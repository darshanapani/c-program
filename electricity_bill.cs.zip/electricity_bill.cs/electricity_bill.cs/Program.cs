﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace electricity_bill.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int unit,u;
            double amt;
            Console .WriteLine("Enter total unit");
            unit=Convert .ToInt32(Console .ReadLine());
            u = unit / 100;
            switch(u)
            {
                case 0:
                case 1:
                Console .WriteLine ("payable amount="+(unit*10));
                break ;

                case 2:
                Console .WriteLine ("payble amount="+((10*100)+(100*15)*15));
                break ;

                case 3:
                Console .WriteLine ("payble amount="+((10*100)+(100*15)+(unit-200)*20));
                break ;

                default :
                Console .WriteLine ("payble amount="+((10*100)+(100*15)+(100*20)+(unit-300)*));
                break ;
            

                Console .Read ();
            
        }
        
    }
 }
