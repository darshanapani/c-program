﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace multidimensian_array.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] bikes = new string[2, 2]
            {
                {"honda","hero"},
                {"ktm","sujuki"}
            };
            foreach(string val1 in bikes)
            {
                Console.WriteLine(val1);
            }
            Console.Read();
        }
    }
}
