﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ROP.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter value of A&B:");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            if (a == b)
                Console.WriteLine("a=b");
            if(a<b)
                Console.WriteLine("a<b");
            if(a>b)
                Console.WriteLine("a>b");
            if(a!=b)
                Console.WriteLine("a!=");
            if(a<=b)
                Console.WriteLine("a<=b");
            if(a>=b)
                Console.WriteLine("a>=b");

            Console.Read();
        }
    }
}
